mgraphics.init();
mgraphics.relative_coords = 1;
mgraphics.autofill = 0;

var localAspect = (this.box.rect[2] - this.box.rect[0]) / (this.box.rect[3] - this.box.rect[1]);
var dim = [1920, 1080];
var aspect = dim[0] / dim[1];
var mg = new MGraphics(dim[0], dim[1]);
mg.relative_coords = 1;
mg.autofill = 0;
var outmatrix = new JitterMatrix(4, "char", 0, 0);

var shapes = [];
var selectedShape = -1;
var selectedPoint = -1;
var lastMousePos = [];
var saveShapes = [];

function initialize(){
	output();
}

function bang(){
	mgraphics.redraw();	
	output();
	notifyclients();	
}

//Draw Shapes and ControlPoints to GUI and to OutputMatrix---------------------------------------------
function paint(){
		mgraphics.rectangle(-1 * localAspect, 1, 2 * localAspect , 2);
		mgraphics.set_source_rgb(0.55, 0.55, 0.55, 1);
		mgraphics.fill();
		
	for(var i = 0; i < shapes.length; ++i){
		var isSelected = selectedShape == i;
		drawShape(shapes[i], isSelected);
		if(isSelected) drawPoints(shapes[i]);
	}		
}

function drawShape(shape, isSelected){
	with(mgraphics){
		for(var i = 0; i < shape.length; ++i){
			var p = [shape[i][0] * localAspect, shape[i][1]];
			if(i == 0) move_to(p);
		    if(shape[i][2] == 1){
				var pi = i - 1 < 0 ? shape.length - 1 : i - 1;
				var pp = [shape[pi][0] * localAspect, shape[pi][1]]; 
				var ni = i + 1 >= shape.length ? 0 : i + 1;
				var np = [shape[ni][0] * localAspect, shape[ni][1]]; 
				curve_to(pp, p, np);
			}else line_to(p);
		}
			close_path();
			set_source_rgb(1,0,0);
			stroke_preserve();
			if(isSelected) set_source_rgb(0,1,0);
			else set_source_rgba(0,0,0,0);
			fill();	
	}		
}
drawShape.local = 1;

function drawPoints(shape){
	with(mgraphics){
		for(var i = 0; i < shape.length; ++i){
			var p = [shape[i][0] * localAspect, shape[i][1]];
				if(shape[i][2] == 1){
 					set_source_rgb(0,0,1);
					var pi = i - 1 < 0 ? shape.length - 1 : i - 1;
					var pp = [shape[pi][0] * localAspect, shape[pi][1]]; 
					var ni = i + 1 >= shape.length ? 0 : i + 1;
					var np = [shape[ni][0] * localAspect, shape[ni][1]]; 
					move_to(pp);
					line_to(p);
					line_to(np);
					stroke();
					if(selectedPoint == i) set_source_rgb(1,1,0);
					ellipse(p[0] - 0.05 / 2, p[1] + 0.05 / 2, 0.05, 0.05);
					fill();
				}
			}
			
		
		for(var j = 0; j < shape.length; ++j){
			var point = [shape[j][0] * localAspect,shape[j][1]];
			var	curve = shape[j][2];
			if( curve == 0){
				if(selectedPoint == j) set_source_rgb(1,1,0);
				else set_source_rgb(1,0,0);
				ellipse(point[0] - 0.05 / 2, point[1] + 0.05 / 2, 0.05, 0.05);
				fill();
			}
		}
	}	
}
drawPoints.local = 1;

function output(){
	
	mg.rectangle(-1 * aspect, 1, 2 * aspect , 2);
	mg.set_source_rgb(0, 0, 0);
	mg.fill();
	
	for(var i = 0; i < shapes.length; ++i){
		shape =	shapes[i];
		with(mg){
			for(var j = 0; j < shape.length; ++j){
				var p = [shape[j][0]* aspect,shape[j][1]];
				if(j == 0) move_to(p);	
		 		if(shape[j][2] == 1){
					var pi = j - 1 < 0 ? shape.length - 1 : j - 1;
					var pp = [shape[pi][0] * aspect, shape[pi][1]]; 
					var ni = j + 1 >= shape.length ? 0 : j + 1;
					var np = [shape[ni][0] * aspect, shape[ni][1]]; 
					curve_to(pp, p, np);
				}else line_to(p);
			}
		close_path();
		set_source_rgb(1,0,0);
		fill();	
		}	
	}
	var theImage = new Image(mg);
	theImage.tonamedmatrix(outmatrix.name);
	outlet(0, "jit_matrix", outmatrix.name);
	gc();	
}

//Handle Mouse Input------------------------------------------------------------------------
function onclick(x,y,but,cmd,shift,capslock,option,ctrl){
	selectedPoint = -1;
	selectedShape = -1;
	var mousePos = sketch.screentoworld(x,y);
	mousePos[0] /=  localAspect;
	
	if(findPoint(mousePos) != 1){
 		for(var i = shapes.length - 1; i >= 0; --i)
			if(intersects(shapes[i], mousePos) == 1){
				selectedShape = i;
				break;
			}
	}
	lastMousePos = mousePos;
	bang();
}
onclick.local = 1;

function findPoint(mousePos){
	loop1:	
	for(var i = 0; i < shapes.length; ++i)		
		for(var j = 0; j < shapes[i].length; ++j)
			if(mousePos[0] < shapes[i][j][0] + 0.03 && mousePos[0] > shapes[i][j][0] - 0.03 
				&& mousePos[1] < shapes[i][j][1] + 0.03 && mousePos[1] > shapes[i][j][1] - 0.03){
					selectedShape = i;
					selectedPoint = j;
					return 1;
			}
	return 0;
}
findPoint.local = 1;

function ondrag(x,y,but,cmd,shift,capslock,option,ctrl){
	var pos = sketch.screentoworld(x,y);
	pos[0] /= localAspect;
	
	if(selectedPoint > -1){
		if (shift) { 
				var xMove = lastMousePos[0] - pos[0];
				var yMove = lastMousePos[1] - pos[1];
				var xVal = 	shapes[selectedShape][selectedPoint][0] - xMove * 0.1;
				var yVal = shapes[selectedShape][selectedPoint][1] - yMove * 0.1;
				shapes[selectedShape][selectedPoint][0] = xVal;
				shapes[selectedShape][selectedPoint][1] = yVal;
				bang();
		} else{
 				shapes[selectedShape][selectedPoint][0] = pos[0];
				shapes[selectedShape][selectedPoint][1] = pos[1];
				bang();
		}
	} else if(selectedShape > -1){
				var xMove = lastMousePos[0] - pos [0];
				var yMove = lastMousePos[1] - pos[1];
 				for( var i = 0; i < shapes[selectedShape].length; ++i){
					shapes[selectedShape][i][0] -= xMove;
					shapes[selectedShape][i][1] -= yMove;
				}
				bang();
			}
	lastMousePos = pos; 
}
ondrag.local = 1;


function intersects(shape, point){
  	var c = 0;
	var i = 0;
 	var j = shape.length - 1;

  	while (i < shape.length) {
    	if (((shape[i][1] > point[1]) != (shape[j][1]>point[1])) &&
     	   (point[0] < (shape[j][0]-shape[i][0]) * (point[1]-shape[i][1]) / (shape[j][1]-shape[i][1]) + shape[i][0]))
       			c = !c;
		j = i++;
  	}
	return c;
}
intersects.local = 1;


//Add and Delete Nodes--------------------------------------------------------------------------------------------------

function addRect(){
	shapes.push([[-0.1 / localAspect, 0.1, 0],[0.1 / localAspect, 0.1, 0],[0.1 / localAspect, -0.1, 0],[-0.1 / localAspect, -0.1, 0]]);
	selectedShape = shapes.length - 1;
	bang();
}

function deleteShape(){
	if(selectedShape > -1){
 		shapes.splice(selectedShape, 1);
		selectedShape = -1;
	}
	bang();
}

function clear(){
		shapes = [];
		selectedShape = -1;
		bang();
}

function addNode(){
	if(selectedPoint > -1){
		var ni = selectedPoint + 1 >= shapes[selectedShape].length ? 0 : selectedPoint + 1;	
		var xPos = (shapes[selectedShape][selectedPoint][0] + shapes[selectedShape][ni][0]) / 2;
		var yPos = (shapes[selectedShape][selectedPoint][1] + shapes[selectedShape][ni][1]) / 2;
		shapes[selectedShape].splice(selectedPoint + 1, 0, [xPos, yPos, 0]); 
		selectedPoint = ni;
		bang();
	}
}

function deleteNode(){
	if(selectedPoint > -1){
 		shapes[selectedShape].splice(selectedPoint, 1);
		selectedPoint = selectedPoint  >= shapes[selectedShape].length ? 0 : selectedPoint;
		if(shapes[selectedShape][selectedPoint][2] == 1) shapes[selectedShape].splice(selectedPoint, 1);
		selectedPoint = -1;
		bang();
	}
}


function addSpline(){
	if(selectedPoint > -1){
		var ni = selectedPoint + 1 >= shapes[selectedShape].length ? 0 : selectedPoint + 1;	
		if(shapes[selectedShape][selectedPoint][2] != 1 && shapes[selectedShape][ni][2] != 1){
			var xPos = (shapes[selectedShape][selectedPoint][0] + shapes[selectedShape][ni][0]) / 2;
			var yPos = (shapes[selectedShape][selectedPoint][1] + shapes[selectedShape][ni][1]) / 2;
			shapes[selectedShape].splice(selectedPoint + 1, 0, [xPos, yPos, 1]); 
			selectedPoint = ni;
		}
		bang();
	}
}

//Save and Restore----------------------------------------------------------------------------------------------
function getvalueof() {
	
	saveShapes = new Array();
	saveShapes.push("Shapes");
	
	for(var i = 0; i < shapes.length; ++i){
		for(var j = 0; j < shapes[i].length; ++j)
			for(var k = 0; k < 3; ++k)
			 saveShapes.push(shapes[i][j][k]);	
		saveShapes.push("EndShape");
	}
		
	return saveShapes;
}

function setvalueof(a) {
	var input = arrayfromargs(arguments);
	var shapeBuffer = [];
	var pointBuffer = [];
	shapes = [];
	selectedShape = -1;
	
	
	for(var i = 1; i < input.length; ++i){
		if(input[i] == "EndShape"){
 			shapes.push(shapeBuffer);
			shapeBuffer = [];
		}else{
 			pointBuffer.push(input[i]);
 			if(pointBuffer.length == 3){
				shapeBuffer.push(pointBuffer);
				pointBuffer = [];
			}
		}
	}
	bang();
}