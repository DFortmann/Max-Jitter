sketch.default2d();

var matrix = [new JitterMatrix(3, "float32", 2, 2), new JitterMatrix(3, "float32", 3, 3),new JitterMatrix(3, "float32", 4, 4)];

var from = 0;
var point = -1;
var lastMousPos = [0, 0];

initialize();
bang();
	
function initialize(){
	
	for(var i = 0; i < 3; ++i){
		matrix[i].adapt = 0;
		matrix[i].interp = 1;
	}
	
	matrix[0].setcell(0, 0, "val", -0.8, -0.8, 0);
	matrix[0].setcell(1, 0, "val", 0.8, -0.8, 0);
	matrix[0].setcell(0, 1, "val", -0.8, 0.8, 0);
	matrix[0].setcell(1, 1, "val", 0.8, 0.8, 0);
}
initialize.local = 1;

function scale(val){
		sketch.glscale(val, val, 1);
		bang();
}

function setDivisions(to){
		matrix[to].frommatrix(matrix[from]);
		from = to;
		outlet(0, "order", to + 1, to + 1);
		bang();
}

function bang(){
	draw();
	output();
	refresh();
}

function draw(){	
	with (sketch) {
		glclearcolor(0.552941, 0.552941, 0.552941, 1);
		glclear();	
		glcolor(1,0,0,1);
		
		
		
		for(var index = 0; index < Math.pow(matrix[from].dim[0],2) ; ++index){
			var x = index % matrix[from].dim[0];
			var y = Math.floor(index / matrix[from].dim[1]);

			moveto(matrix[from].getcell(x, y));
			circle(0.05);
			
			
			if( from == 0){
				if(index == 0){
					lineto(matrix[from].getcell(x + 1, y));
					moveto(matrix[from].getcell(x, y));
					lineto(matrix[from].getcell(x, y + 1));
				}else if(index ==1)
					lineto(matrix[from].getcell(x, y + 1));
				else if(index ==2)
					lineto(matrix[from].getcell(x + 1, y));
			}else if(from == 1){
				if(index == 2 || index == 5)
					lineto(matrix[from].getcell(x, y + 1));
				else if(index == 6 || index == 7)
					lineto(matrix[from].getcell(x + 1, y));
				else if( index != 8){
					lineto(matrix[from].getcell(x + 1, y));
					moveto(matrix[from].getcell(x, y));
					lineto(matrix[from].getcell(x, y + 1));
				}
			}else if(from == 2){
				if( index == 3 || index == 7 || index == 11)
					lineto(matrix[from].getcell(x, y + 1));
				else if(index >= 12 && index < 15)
					lineto(matrix[from].getcell(x + 1, y));
				else if(index != 15){
					lineto(matrix[from].getcell(x + 1, y));
					moveto(matrix[from].getcell(x, y));
					lineto(matrix[from].getcell(x, y + 1));
				}
			}
		}
	} 
}
draw.local = 1;

function onclick(x,y, but,cmd, shift){
	var pos = sketch.screentoworld(x,y);
		point = -1;
	
		for( var index = 0; index < Math.pow(matrix[from].dim[0], 2); ++index){
			var x = index % matrix[from].dim[0];
			var y = Math.floor(index / matrix[from].dim[1]);
			var p = matrix[from].getcell(x, y);
			
			if(pos[0] < p[0] + 0.07 && pos[0] > p[0] - 0.07 
				&& pos[1] < p[1] + 0.07 && pos[1] > p[1] - 0.07){
					point = index;
					break;
			}
		}
	lastMousePos = pos;	
}
onclick.local = 1;


function ondrag(x, y, but, cmd, capslock, option, ctrl){
	if(but == 1){
		var pos = sketch.screentoworld(x,y);
	
	if(point >= 0){
				var xMove = lastMousePos[0] - pos[0];
				var yMove = lastMousePos[1] - pos[1];
				var x = point % matrix[from].dim[0];
				var y = Math.floor(point / matrix[from].dim[1]);
				var xVal = 0;
				var yVal = 0;
		if (cmd) { 
				xVal = matrix[from].getcell(x, y)[0] - xMove * 0.1;
				yVal = matrix[from].getcell(x, y)[1] - yMove * 0.1;
			}else {
				xVal = pos[0];
				yVal = pos[1];
			}
			matrix[from].setcell(x, y, "val", xVal, yVal, 0);		
			bang();
		}
		lastMousePos = pos; 
	}
	notifyclients();
}
ondrag.local = 1;

function ondblclick(){
	initialize();
	matrix[from].frommatrix(matrix[0]);
	bang();
	notifyclients();
}
ondblclick.local = 1; 


function output(){
	var outMatrix = new JitterMatrix(3, "float32", matrix[from].dim[0], matrix[from].dim[1]);


	for( var index = 0; index < Math.pow(matrix[from].dim[0], 2); ++index){
			var x = index % matrix[from].dim[0];
			var y = Math.floor(index / matrix[from].dim[1]);
			var xVal = matrix[from].getcell(x, y)[0] * 1.25;
			var yVal = matrix[from].getcell(x, y)[1] * 1.25;
			
			outMatrix.setcell(x, y, "val", xVal, yVal, 0);		
	}
	outlet(0, "ctlmatrix", "jit_matrix", outMatrix.name);
}
output.local = 1;


function getvalueof() {
	
	var arraySize = Math.pow(matrix[from].dim[0],2) * 2;
	var array = new Array(arraySize);
	
		for( var index = 0; index < arraySize / 2; ++index){
			var x = index % matrix[from].dim[0];
			var y = Math.floor(index / matrix[from].dim[1]);
			var p = matrix[from].getcell(x, y);
			
			for(var j = 0; j < 2; ++j)
				array[index * 2 + j] = p[j];
		}
	return array;
}

function setvalueof(a) {
	var array = arrayfromargs(arguments);	
	
	switch(array.length){
		case 8:  setDivisions(0);	break;
		case 18: setDivisions(1);  break;
		case 32: setDivisions(2);
	}
	
	for(var index = 0; index < array.length / 2; ++index){
		var x = index % matrix[from].dim[0];
		var y = Math.floor(index / matrix[from].dim[1]);
		var p = [2];
		
		for(var j = 0; j < 2; ++j)
			p[j] = array[index * 2 + j];

		matrix[from].setcell(x, y, "val", p[0], p[1], 0);
	}	
	bang();
}

