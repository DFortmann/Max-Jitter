sketch.default2d();

var vertices = [-1, 1, 1, 1, 1, -1, -1, -1];
var vertex = -1;
var lastMousPos = [0, 0];
var scale = 1.;
var pos = [0, 0]
draw();
initialze();


function initialze(){
	sketch.glscale(0.8, 0.8, 1.);
	bang();
}

function setScale(val){
	scale = val;
	bang();
}

function setPos(){
	pos = arrayfromargs(arguments);
	bang();
}

function draw(){	
	with (sketch) {
		glclearcolor(0.552941, 0.552941, 0.552941, 1);
		glclear();	
		glcolor(1,0,0,1);
		
		for(var index = 0; index < vertices.length - 1; index += 2){
			moveto(vertices[index], vertices[index + 1]);
			circle(0.05);
			if(index + 3 < vertices.length) lineto(vertices[index + 2], vertices[index + 3]);
			else lineto(vertices[0], vertices[1]);
		}
	}
}
draw.local = 1;

function bang(){
	draw();
	output();
	refresh();
}

function onclick(x,y, but){
		var point = sketch.screentoworld(x,y);
		vertex = -1;
	
		for( var i = 0; i < vertices.length - 1; i += 2){
			if(point[0] < vertices[i] + 0.07 && point[0] > vertices[i] - 0.07 
				&& point[1] < vertices[i + 1] + 0.07 && point[1] > vertices[i + 1] - 0.07){
					vertex = i;
					break;
			}
		}
	lastMousePos = point;	
}
onclick.local = 1;

function ondrag(x,y,but,cmd,shift,capslock,option,ctrl){
	if(but == 1){
		var pos = sketch.screentoworld(x,y);
	
		if (shift) { 
			if(vertex >= 0){
				var xMove = lastMousePos[0] - pos [0];
				var yMove = lastMousePos[1] - pos[1];
				var xVal = 	vertices[vertex] - xMove * 0.1;
				var yVal = vertices[vertex + 1] - yMove * 0.1;
 				vertices[vertex] = xVal;
				vertices[vertex + 1] = yVal;
				bang();
			}
		} else {
			if(vertex >= 0){
 				vertices[vertex] = pos[0];
				vertices[vertex + 1] = pos[1];
				bang();
			}
		}
		lastMousePos = pos; 
	}
		notifyclients();
}
ondrag.local = 1;

function ondblclick(){
	vertices = [-1, 1, 1, 1, 1, -1, -1, -1];
	bang();
	notifyclients();
}
ondblclick.local = 1; 

function output(){
		var corner;
		
	for( var i = 0; i < vertices.length - 1; i += 2){
			if(i == 0) corner = "upper_left";
			else if(i == 2) corner = "upper_right";
			else if(i == 4) corner = "lower_right";
			else corner = "lower_left";
			
			var x = (vertices[i] * scale + pos[0] + 1) / 2 ;
			var y = (vertices[i + 1] * -1 * scale + pos[1] + 1)  / 2 ;
			
			outlet(0,corner + " " + x + " " + y);
		}
	}
output.local = 1;


function getvalueof() {
	return vertices;
}

function setvalueof(a) {
	vertices = arrayfromargs(arguments);
	bang();
}

